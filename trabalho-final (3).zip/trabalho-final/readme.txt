http://localhost:8080/swagger-ui/index.html?configUrl=/v3/api-docs/swagger-config#/

http://localhost:8080/h2-ui