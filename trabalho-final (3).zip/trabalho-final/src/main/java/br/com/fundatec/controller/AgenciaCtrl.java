package br.com.fundatec.controller;


import br.com.fundatec.model.Agencia;
import br.com.fundatec.service.AgenciaService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Tag(name = "Agencia")
@RestController
@RequestMapping("agencia")
public class AgenciaCtrl {

    private final AgenciaService agenciaService;

    public AgenciaCtrl(AgenciaService agenciaService) {
        this.agenciaService = agenciaService;
    }

    @PostMapping
    public Agencia criar(Agencia agencia){
        return agenciaService.criar(agencia);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Integer id){
        agenciaService.deletar(id);
    }

    @PutMapping
    public Agencia editar(@RequestBody Agencia agencia){
        return agenciaService.editar(agencia);
    }


    @GetMapping("/{id}")
    public Optional<Agencia> pesquisar(@PathVariable Integer id){
        return agenciaService.pesquisar(id);
    }
}
