package br.com.fundatec.repository;

import br.com.fundatec.model.Banco;
import br.com.fundatec.model.Conta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface ContaRepository extends JpaRepository<Conta, Integer> {

    @Override
    Optional<Conta> findById(Integer id);


}
