package br.com.fundatec.service;

import br.com.fundatec.model.Conta;
import br.com.fundatec.repository.ContaRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ContaService {

    private final ContaRepository repository;

    public ContaService(ContaRepository repository) {
        this.repository = repository;

    }

    public Conta criar(Conta conta) {
        return repository.save(conta);
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }

    public Conta editar(Conta conta) {
        return repository.save(conta);
    }

    public Optional<Conta> pesquisar(Integer id) {
        return repository.findById(id);
    }
}
