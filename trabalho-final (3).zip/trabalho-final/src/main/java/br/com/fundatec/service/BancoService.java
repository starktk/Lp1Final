package br.com.fundatec.service;

import br.com.fundatec.model.Banco;
import br.com.fundatec.repository.BancoRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class BancoService {

    private final BancoRepository bancoRepository;

    public BancoService(BancoRepository repository) {
        this.bancoRepository = repository;
    }

    public Banco criar(Banco banco){

        if(banco == null) {
            throw  new IllegalArgumentException();
        }

        if(banco.getAgencias() != null) {
            banco.getAgencias().stream().forEach(a -> a.setBanco(banco));
        }

        return bancoRepository.save(banco);
    }
    public void deletar(Integer id) {
        bancoRepository.deleteById(id);
    }

    public Banco editar(Banco banco) {
      return bancoRepository.save(banco);
    }
    public Optional<Banco> pesquisar(Integer id) {
        return bancoRepository.findById(id);
    }
}
