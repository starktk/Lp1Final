package br.com.fundatec.controller;

import br.com.fundatec.model.Cliente;
import br.com.fundatec.service.ClienteService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("cliente")
public class ClienteCtrl {

    private final ClienteService clienteService;

    public ClienteCtrl(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @PostMapping
    public Cliente criar(Cliente cliente) {
        return clienteService.criar(cliente);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Integer id) {
        clienteService.deletar(id);
    }

    @PutMapping
    public Cliente editar(@RequestBody Cliente cliente) {
        return clienteService.editar(cliente);
    }

    @GetMapping("/{id}")
    public Optional<Cliente> pesquisar(@PathVariable Integer id) {
        return clienteService.pesquisar(id);
    }
    @GetMapping("busca-cpf")
    public Cliente pesquisarPorCpf(@RequestParam String cpf) {
        return clienteService.pesquisarPorCpf(cpf);
    }
}
