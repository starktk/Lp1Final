package br.com.fundatec.controller;

import br.com.fundatec.model.Conta;
import br.com.fundatec.service.ContaService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("conta")
public class ContaCtrl {

    private final ContaService contaService;


    public ContaCtrl(ContaService contaService) {
        this.contaService = contaService;
    }
    @PostMapping
    public Conta criar(Conta conta) {
        return contaService.criar(conta);
    }
    @DeleteMapping
    public void deletar(Integer id) {
        contaService.deletar(id);
    }
    @PutMapping
    public Conta editar(@RequestBody Conta conta) {
        return contaService.editar(conta);
    }
    @GetMapping
    public Optional<Conta> pesquisar(Integer id) {
        return contaService.pesquisar(id);
    }
}
