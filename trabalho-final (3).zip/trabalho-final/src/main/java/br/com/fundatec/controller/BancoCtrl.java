package br.com.fundatec.controller;

import br.com.fundatec.model.Banco;
import br.com.fundatec.service.BancoService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("banco")
public class BancoCtrl {

    private final BancoService bancoService;


    public BancoCtrl(BancoService bancoService) {
        this.bancoService = bancoService;
    }

    @PostMapping
    public Banco criar(@RequestBody  Banco banco) {
        return bancoService.criar(banco);
    }

    @DeleteMapping
    public void deletar(@PathVariable Integer id) {
        bancoService.deletar(id);
    }

    @PutMapping
    public Banco editar(@RequestBody Banco banco) {
        return bancoService.editar(banco);
    }

    @GetMapping("{id}")
    public Optional<Banco> pesquisar(@PathVariable Integer id) {
        return bancoService.pesquisar(id);
    }
}
