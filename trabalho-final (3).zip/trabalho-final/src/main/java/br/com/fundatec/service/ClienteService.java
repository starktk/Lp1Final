package br.com.fundatec.service;

import br.com.fundatec.model.Cliente;
import br.com.fundatec.repository.ClienteRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;

    private final ObjectMapper objectMapper;


    public ClienteService (ClienteRepository repository,ObjectMapper objectMapper){
        this.clienteRepository = repository;
        this.objectMapper = objectMapper;
    }

    public Cliente criar(Cliente cliente) {
        return clienteRepository.save(cliente);
    }
    public void deletar(Integer id) {
        clienteRepository.deleteById(id);
    }
    public Cliente editar(Cliente cliente) {
        return clienteRepository.save(cliente);
    }
    public Optional<Cliente> pesquisar(Integer id) {
        return clienteRepository.findById(id);
    }
    public Cliente pesquisarPorCpf(String cpf) {
        Cliente cliente = clienteRepository.findByCpf(cpf);

        if (cliente == null) {
            return null;
        }
        Cliente clienteRetorno = objectMapper.convertValue(cliente, Cliente.class);


        return clienteRetorno;
    }

}
